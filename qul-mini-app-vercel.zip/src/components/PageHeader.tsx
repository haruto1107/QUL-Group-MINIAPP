"use client";

import { useRouter } from "next/navigation";

export default function PageHeader({
  title,
  showBack = true,
}: {
  title: string;
  showBack?: boolean;
}) {
  const router = useRouter();

  return (
    <header className="flex items-center gap-2 px-3 pb-1 pt-6">
      {showBack && (
        <button
          onClick={() => router.back()}
          aria-label="戻る"
          className="flex h-9 w-9 items-center justify-center rounded-full text-lg text-ink active:bg-qul-tint"
        >
          ‹
        </button>
      )}
      <h1 className="px-1 text-[17px] font-semibold text-ink">{title}</h1>
    </header>
  );
}
