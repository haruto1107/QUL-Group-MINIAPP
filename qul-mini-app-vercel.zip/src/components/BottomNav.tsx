"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_ITEMS = [
  { href: "/", label: "Home", icon: "🏠" },
  { href: "/pass", label: "PASS", icon: "🎫" },
  { href: "/reserve", label: "Reserve", icon: "📅" },
  { href: "/my", label: "My", icon: "👤" },
] as const;

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-line-hairline bg-white/95 backdrop-blur"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="mx-auto flex max-w-app items-stretch justify-around">
        {NAV_ITEMS.map((item) => {
          const active =
            item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex flex-1 flex-col items-center gap-1 py-2.5"
            >
              <span
                className={`text-xl transition-opacity ${
                  active ? "opacity-100" : "opacity-50"
                }`}
                aria-hidden
              >
                {item.icon}
              </span>
              <span
                className={`text-[11px] ${
                  active ? "font-semibold text-qul-dark" : "text-ink-faint"
                }`}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
