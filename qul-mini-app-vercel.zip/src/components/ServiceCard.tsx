import Link from "next/link";
import type { ReactNode } from "react";

interface ServiceCardProps {
  href: string;
  icon: ReactNode;
  title: string;
  value: string;
  valueEmphasis?: boolean;
}

export default function ServiceCard({
  href,
  icon,
  title,
  value,
  valueEmphasis,
}: ServiceCardProps) {
  return (
    <Link
      href={href}
      className="flex items-center justify-between rounded-card bg-white px-5 py-4 shadow-soft active:scale-[0.99]"
    >
      <div className="flex items-center gap-3.5">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-qul-tint text-xl">
          {icon}
        </div>
        <div className="flex flex-col">
          <span className="text-[13px] text-ink-soft">{title}</span>
          <span
            className={
              valueEmphasis
                ? "text-lg font-semibold text-ink"
                : "text-sm font-medium text-ink"
            }
          >
            {value}
          </span>
        </div>
      </div>
      <span className="text-ink-faint" aria-hidden>
        ›
      </span>
    </Link>
  );
}
