export default function NotInLineScreen() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-white px-6 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-qul-tint">
        <span className="text-2xl" aria-hidden>
          💬
        </span>
      </div>
      <h1 className="text-lg font-semibold text-ink">QUL Mini App</h1>
      <p className="text-sm leading-relaxed text-ink-soft">
        このサービスはLINEからご利用ください。
        <br />
        LINEでQULを開いてください。
      </p>
    </div>
  );
}
