export default function LoadingScreen() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-white px-6 text-center">
      <div className="h-9 w-9 animate-spin rounded-full border-2 border-qul-tint border-t-qul" />
      <p className="text-sm text-ink-soft">QULを読み込んでいます…</p>
    </div>
  );
}
