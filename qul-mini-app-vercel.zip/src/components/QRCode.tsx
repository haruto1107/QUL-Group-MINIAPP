"use client";

import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { useLiff } from "./LiffProvider";

/**
 * QR関連の用途。将来的に Q-PASS / QUL Point / QUL Pay / 店舗受付 / イベント受付
 * などを追加する際は、ここに種別を足すだけで済むようにしている。
 */
export type QRPurpose =
  | "pass"
  | "point"
  | "pay"
  | "store-checkin"
  | "event-checkin";

interface QRDisplayProps {
  purpose: QRPurpose;
  value: string;
  size?: number;
}

/** 自分のQRコードを表示する（Q-PASSなど） */
export function QRDisplay({ purpose, value, size = 220 }: QRDisplayProps) {
  return (
    <div
      className="flex flex-col items-center gap-3 rounded-card bg-white p-6 shadow-soft"
      data-qr-purpose={purpose}
    >
      <div className="rounded-2xl border border-line-hairline p-4">
        <QRCodeSVG value={value} size={size} fgColor="#1C1E21" />
      </div>
      <p className="text-xs text-ink-faint">スタッフの端末にご提示ください</p>
    </div>
  );
}

interface QRScannerButtonProps {
  purpose: QRPurpose;
  onResult: (value: string) => void;
  label?: string;
}

/** LIFFのQRスキャン機能を呼び出すボタン */
export function QRScannerButton({
  purpose,
  onResult,
  label = "QRコードを読み取る",
}: QRScannerButtonProps) {
  const { liff } = useLiff();
  const [scanning, setScanning] = useState(false);
  const [notSupported, setNotSupported] = useState(false);

  async function handleScan() {
    if (!liff) return;
    setScanning(true);
    try {
      if (!liff.scanCodeV2) {
        setNotSupported(true);
        return;
      }
      const result = await liff.scanCodeV2();
      if (result?.value) {
        onResult(result.value);
      }
    } catch (err) {
      console.error(`QRスキャンエラー (${purpose}):`, err);
    } finally {
      setScanning(false);
    }
  }

  if (notSupported) {
    return (
      <p className="text-xs text-ink-faint">
        この環境ではQRスキャンをご利用いただけません。LINEアプリでお試しください。
      </p>
    );
  }

  return (
    <button
      onClick={handleScan}
      disabled={scanning}
      className="w-full rounded-pill bg-qul px-6 py-3.5 text-sm font-medium text-white shadow-soft disabled:opacity-60 active:scale-[0.98]"
    >
      {scanning ? "起動中…" : label}
    </button>
  );
}
