"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import type Liff from "@line/liff";
import type { LiffProfile } from "@/types";
import LoadingScreen from "./LoadingScreen";
import ErrorScreen from "./ErrorScreen";
import NotInLineScreen from "./NotInLineScreen";

type LiffStatus = "loading" | "ready" | "error" | "not-in-client-and-no-login";

interface LiffContextValue {
  liff: typeof Liff | null;
  profile: LiffProfile | null;
  status: LiffStatus;
  retry: () => void;
}

const LiffContext = createContext<LiffContextValue>({
  liff: null,
  profile: null,
  status: "loading",
  retry: () => {},
});

export function useLiff() {
  return useContext(LiffContext);
}

export default function LiffProvider({ children }: { children: ReactNode }) {
  const [liffObj, setLiffObj] = useState<typeof Liff | null>(null);
  const [profile, setProfile] = useState<LiffProfile | null>(null);
  const [status, setStatus] = useState<LiffStatus>("loading");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;

    async function init() {
      setStatus("loading");
      try {
        const liffId = process.env.NEXT_PUBLIC_LIFF_ID;
        if (!liffId) {
          throw new Error("LIFF IDが設定されていません");
        }

        const liffModule = (await import("@line/liff")).default;

        await liffModule.init({ liffId });

        if (cancelled) return;
        setLiffObj(liffModule);

        // LINEアプリ外（通常ブラウザ）から、未ログインでアクセスされた場合
        if (!liffModule.isInClient() && !liffModule.isLoggedIn()) {
          setStatus("not-in-client-and-no-login");
          return;
        }

        // LINEアプリ内だが未ログインの場合はログインを促す
        if (!liffModule.isLoggedIn()) {
          liffModule.login();
          return;
        }

        const liffProfile = await liffModule.getProfile();
        if (cancelled) return;

        setProfile({
          userId: liffProfile.userId,
          displayName: liffProfile.displayName,
          pictureUrl: liffProfile.pictureUrl,
          statusMessage: liffProfile.statusMessage,
        });
        setStatus("ready");
      } catch (err) {
        console.error("LIFF init error:", err);
        if (!cancelled) setStatus("error");
      }
    }

    init();
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  const retry = () => setAttempt((n) => n + 1);

  if (status === "loading") {
    return <LoadingScreen />;
  }

  if (status === "not-in-client-and-no-login") {
    return <NotInLineScreen />;
  }

  if (status === "error") {
    return <ErrorScreen onRetry={retry} />;
  }

  return (
    <LiffContext.Provider value={{ liff: liffObj, profile, status, retry }}>
      {children}
    </LiffContext.Provider>
  );
}
