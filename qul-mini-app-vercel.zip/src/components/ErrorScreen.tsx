export default function ErrorScreen({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-5 bg-white px-6 text-center">
      <p className="text-base font-medium text-ink">
        読み込みに失敗しました。
        <br />
        もう一度お試しください。
      </p>
      <button
        onClick={onRetry}
        className="rounded-pill bg-qul px-8 py-3 text-sm font-medium text-white shadow-soft active:scale-[0.98]"
      >
        再読み込み
      </button>
    </div>
  );
}
