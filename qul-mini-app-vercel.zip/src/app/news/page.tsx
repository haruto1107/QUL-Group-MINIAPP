"use client";

import PageHeader from "@/components/PageHeader";

export default function NewsPage() {
  // MVPでは notifications テーブル未接続のためプレースホルダー表示。
  // 接続時は Supabase の notifications テーブルを取得するAPI Routeを追加し、
  // このページから呼び出す想定。
  return (
    <main className="mx-auto min-h-dvh max-w-app bg-white pb-16">
      <PageHeader title="お知らせ" />

      <section className="px-5 pt-4">
        <div className="rounded-card bg-white px-6 py-14 text-center shadow-softer">
          <p className="text-sm text-ink-soft">現在お知らせはありません。</p>
        </div>
      </section>
    </main>
  );
}
