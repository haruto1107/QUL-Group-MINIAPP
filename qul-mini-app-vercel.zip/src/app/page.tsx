"use client";

import Image from "next/image";
import Link from "next/link";
import { useLiff } from "@/components/LiffProvider";
import { useQulData } from "@/lib/useQulData";
import ServiceCard from "@/components/ServiceCard";
import BottomNav from "@/components/BottomNav";

export default function HomePage() {
  const { profile } = useLiff();
  const { data } = useQulData();

  return (
    <main className="mx-auto min-h-dvh max-w-app bg-white pb-24">
      <header className="flex items-center gap-3 px-5 pb-2 pt-8">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-qul text-sm font-bold text-white">
          Q
        </div>
        <span className="text-[15px] font-semibold tracking-tight text-ink">
          QUL
        </span>
      </header>

      <section className="px-5 pb-6 pt-2">
        {profile ? (
          <div className="flex items-center gap-3">
            {profile.pictureUrl && (
              <Image
                src={profile.pictureUrl}
                alt=""
                width={40}
                height={40}
                className="rounded-full"
              />
            )}
            <p className="text-[17px] font-semibold text-ink">
              こんにちは、{profile.displayName}さん
            </p>
          </div>
        ) : (
          <p className="text-[17px] font-semibold text-ink">こんにちは</p>
        )}
      </section>

      <section className="flex flex-col gap-3 px-5">
        <ServiceCard
          href="/point"
          icon="⭐"
          title="QUL Point"
          value={`${data.pointBalance.toLocaleString()} pt`}
          valueEmphasis
        />
        <ServiceCard href="/pass" icon="🎫" title="Q-PASS" value="QRコードを表示" />
        <ServiceCard href="/pay" icon="💰" title="QUL Pay" value="残高を確認" />
        <ServiceCard
          href="/reserve"
          icon="📅"
          title="QUL Reserve"
          value="予約を確認"
        />
      </section>

      <section className="mt-8 px-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-[13px] font-semibold text-ink-soft">
            QULからのお知らせ
          </h2>
          <Link href="/news" className="text-[12px] text-qul-dark">
            すべて見る
          </Link>
        </div>
        <NewsList />
      </section>

      <BottomNav />
    </main>
  );
}

function NewsList() {
  // MVPでは news テーブル接続前のプレースホルダー表示。
  // 準備ができ次第、Supabaseの notifications テーブルから取得するAPIに差し替える。
  return (
    <div className="rounded-card bg-white px-5 py-8 text-center shadow-softer">
      <p className="text-sm text-ink-faint">現在お知らせはありません</p>
    </div>
  );
}
