"use client";

import { useQulData } from "@/lib/useQulData";
import BottomNav from "@/components/BottomNav";
import PageHeader from "@/components/PageHeader";

export default function ReservePage() {
  const { data, loading } = useQulData();

  return (
    <main className="mx-auto min-h-dvh max-w-app bg-white pb-24">
      <PageHeader title="Reserve" showBack={false} />

      <section className="px-5 pt-4">
        {loading ? (
          <p className="py-10 text-center text-sm text-ink-faint">
            読み込み中…
          </p>
        ) : data.reservationCount > 0 ? (
          <p className="py-4 text-sm text-ink-soft">
            現在 {data.reservationCount} 件の予約があります。
          </p>
        ) : (
          <div className="rounded-card bg-white px-6 py-14 text-center shadow-softer">
            <p className="text-sm text-ink-soft">現在、予約はありません。</p>
          </div>
        )}
      </section>

      <BottomNav />
    </main>
  );
}
