"use client";

import { useLiff } from "@/components/LiffProvider";
import { useQulData } from "@/lib/useQulData";
import { QRDisplay } from "@/components/QRCode";
import BottomNav from "@/components/BottomNav";
import PageHeader from "@/components/PageHeader";

export default function PassPage() {
  const { profile } = useLiff();
  const { data, loading } = useQulData();

  const passValue = data.passCode ?? profile?.userId ?? "";

  return (
    <main className="mx-auto min-h-dvh max-w-app bg-white pb-24">
      <PageHeader title="Q-PASS" />

      <section className="px-5 pt-4">
        {loading ? (
          <div className="rounded-card bg-white p-10 text-center shadow-softer">
            <p className="text-sm text-ink-faint">読み込み中…</p>
          </div>
        ) : data.passCode ? (
          <QRDisplay purpose="pass" value={passValue} />
        ) : (
          <div className="rounded-card bg-white px-6 py-10 text-center shadow-softer">
            <p className="text-sm text-ink-soft">
              Q-PASSは準備中です。
              <br />
              発行され次第、ここに表示されます。
            </p>
          </div>
        )}
      </section>

      <BottomNav />
    </main>
  );
}
