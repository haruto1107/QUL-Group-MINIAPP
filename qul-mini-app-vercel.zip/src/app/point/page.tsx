"use client";

import { useQulData } from "@/lib/useQulData";
import PageHeader from "@/components/PageHeader";

export default function PointPage() {
  const { data, loading } = useQulData();

  return (
    <main className="mx-auto min-h-dvh max-w-app bg-white pb-16">
      <PageHeader title="QUL Point" />

      <section className="px-5 pt-6">
        <div className="rounded-card bg-qul-tint px-6 py-8 text-center">
          <p className="text-xs text-ink-soft">現在のポイント</p>
          <p className="mt-2 text-4xl font-semibold text-ink">
            {loading ? "—" : data.pointBalance.toLocaleString()}
            <span className="ml-1 text-base font-medium text-ink-soft">pt</span>
          </p>
        </div>
      </section>

      <section className="mt-8 px-5">
        <h2 className="mb-3 text-[13px] font-semibold text-ink-soft">
          ポイント履歴
        </h2>
        <div className="rounded-card bg-white px-6 py-10 text-center shadow-softer">
          <p className="text-sm text-ink-faint">履歴は準備中です</p>
        </div>
      </section>
    </main>
  );
}
