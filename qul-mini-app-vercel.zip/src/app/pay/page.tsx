"use client";

import PageHeader from "@/components/PageHeader";

export default function PayPage() {
  return (
    <main className="mx-auto min-h-dvh max-w-app bg-white pb-16">
      <PageHeader title="QUL Pay" />

      <section className="px-5 pt-6">
        <div className="rounded-card bg-qul-tint px-6 py-8 text-center">
          <p className="text-xs text-ink-soft">残高</p>
          <p className="mt-2 text-4xl font-semibold text-ink">
            —<span className="ml-1 text-base font-medium text-ink-soft">円</span>
          </p>
          <p className="mt-3 text-xs text-ink-faint">
            QUL Payは準備中です。ご利用開始まで今しばらくお待ちください。
          </p>
        </div>
      </section>
    </main>
  );
}
