"use client";

import Image from "next/image";
import { useLiff } from "@/components/LiffProvider";
import { useQulData } from "@/lib/useQulData";
import BottomNav from "@/components/BottomNav";
import PageHeader from "@/components/PageHeader";

export default function MyPage() {
  const { profile } = useLiff();
  const { data } = useQulData();

  return (
    <main className="mx-auto min-h-dvh max-w-app bg-white pb-24">
      <PageHeader title="My" showBack={false} />

      <section className="flex flex-col items-center gap-3 px-5 pb-6 pt-4">
        {profile?.pictureUrl && (
          <Image
            src={profile.pictureUrl}
            alt=""
            width={72}
            height={72}
            className="rounded-full"
          />
        )}
        <p className="text-[17px] font-semibold text-ink">
          {profile?.displayName ?? "ゲスト"}
        </p>
        <p className="text-xs text-ink-faint">
          QUL ID: {data.qulId ?? "未登録"}
        </p>
      </section>

      <section className="flex flex-col gap-3 px-5">
        <InfoRow label="QUL Point" value={`${data.pointBalance.toLocaleString()} pt`} />
        <InfoRow label="QUL Pay 残高" value="準備中" />
        <InfoRow label="予約" value={`${data.reservationCount} 件`} />
        <InfoRow label="通知設定" value="オン" />
      </section>

      <BottomNav />
    </main>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-card bg-white px-5 py-4 shadow-softer">
      <span className="text-sm text-ink-soft">{label}</span>
      <span className="text-sm font-medium text-ink">{value}</span>
    </div>
  );
}
